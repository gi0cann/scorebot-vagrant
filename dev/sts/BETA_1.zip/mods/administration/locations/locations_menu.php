<?php if(isset($_SESSION['user_id'])) { ?>
	<h1>Locations</h1>
	<p><a href="#" id="add_location">Add Location</a></p>
<?php } ?>