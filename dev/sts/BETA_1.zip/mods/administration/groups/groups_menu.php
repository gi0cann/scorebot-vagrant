<?php if(isset($_SESSION['user_id'])) { ?>
	<h1>Groups</h1>
	<p><a href="#" id="add_category">Add Group</a></p>
<?php } ?>