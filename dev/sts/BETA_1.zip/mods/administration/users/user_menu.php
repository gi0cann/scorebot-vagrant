<?php if(isset($_SESSION['user_id'])) { ?>
	<h1>Users</h1>
	<p><a href="#" id="add_user">Add User</a></p>
<?php } ?>