<?php if(isset($_SESSION['user_id'])) { ?>
	<h1>Permissions</h1>
<?php } ?>