<?php if(isset($_SESSION['user_id'])) { ?>
	<h1>Categories</h1>
	<p><a href="#" id="add_category">Add Category</a></p>
<?php } ?>